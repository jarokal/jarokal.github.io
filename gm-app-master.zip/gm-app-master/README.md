# GM-APP
- [Trello](https://trello.com/b/bjFSzJOJ)
- [Docs & Specs](https://docs.google.com/document/d/1x97dWvOL70yIZtwScj9ZK5pytpJ4TPK2Got9SyVgsCc/edit?usp=sharing)

## Hvězdy
- D3 lib: https://github.com/ofrohn/d3-celestial

## Města
- Open Street Maps: https://wiki.openstreetmap.org/wiki/API
- MapBox GL-JS: https://docs.mapbox.com/mapbox-gl-js/api/
- Leaflet JS: https://leafletjs.com/

### Užitečné odkazy
- Gala Maps Eshop: https://shop.galamaps.cz
- Tailwind: https://tailwindcss.com/
